# Diario de Trading (PWA)

Diario de operaciones SMC / ICT instalable en Android e iOS.

## Cómo subirlo a GitHub Pages (paso a paso)

### 1. Crear el repositorio
1. Entra a [github.com](https://github.com) e inicia sesión.
2. Pulsa **New repository**.
3. Nombre recomendado: `diario-trading`
4. Déjalo **público**.
5. **No** marques "Add a README" (ya lo tienes).
6. Crea el repositorio.

### 2. Subir los archivos
Tienes dos formas:

**Opción A – Desde la web de GitHub (más fácil)**
1. Entra al repositorio vacío.
2. Pulsa **uploading an existing file**.
3. Arrastra **todos** estos archivos:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon.svg`
   - `README.md` (opcional)
4. Pulsa **Commit changes**.

**Opción B – Con Git (si sabes usarlo)**
```bash
git init
git add .
git commit -m "Diario de Trading PWA"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/diario-trading.git
git push -u origin main
```

### 3. Activar GitHub Pages
1. En el repositorio ve a **Settings** → **Pages**.
2. En **Source** elige:
   - Branch: `main`
   - Folder: `/ (root)`
3. Guarda.
4. Espera 1-2 minutos.
5. Te aparecerá el enlace:
   ```
   https://TU_USUARIO.github.io/diario-trading/
   ```

### 4. Instalar en Android
1. Abre el enlace de arriba **con Chrome** en tu teléfono.
2. Menú **⋮** → **Instalar aplicación** (o **Añadir a la pantalla de inicio**).
3. Listo. Ya tienes la app instalada.

## Archivos incluidos
| Archivo        | Descripción                  |
|----------------|------------------------------|
| `index.html`   | La aplicación completa       |
| `manifest.json`| Configuración de la PWA      |
| `sw.js`        | Service Worker (offline)     |
| `icon.svg`     | Icono de la app              |

## Notas
- Los datos se guardan en el navegador del teléfono (`localStorage`).
- Funciona offline una vez instalada.
- También se puede instalar en iPhone (Safari → Compartir → Añadir a pantalla de inicio).
